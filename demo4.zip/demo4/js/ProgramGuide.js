var data = [
    {
        'menu': '主菜单',
        'items': ['频道浏览', '喜爱频道', '节目指南', '信息服务', '系统设置', '广播邮件', '用户账户'],
        'cName': ['icon-wxbbiaowang', 'icon-wxbgongju', 'icon-wxbmingxingdianpu', 'icon-wxbpinpaibao', 'icon-wxbpinpaibao', 'icon-wxbzhuye', 'icon-wxbsousuotuiguang'],
        'list': ['频道名称', '节目名称', '播放时间'],
        'footerimage': '',
        'rightTopimage': 'img/a1.jpg',
        'rightBottomimage': ''
    },
    {
        'linked': '频道浏览',
        'items': ['内蒙古卫视', '广西卫视', '广东卫视', 'CCTV-1', 'CCTV-2', 'CCTV-3', 'CCTV444', 'CCTV555', 'cctba', 'ccbe5'],
        'list': ['内蒙古卫视', '转播中央台新闻', '19:00-19:30'],
        'footerimage': '',
        'rightTopimage': 'img/a2.jpg',
        'rightBottomimage': ''
    },
    {
        'linked': '喜爱频道',
        'items': [],
        'list': ['马猴烧酒育成计划', '夏目', '超自然9'],
        'footerimage': '',
        'rightTopimage': 'img/a3.jpg',
        'rightBottomimage': ''
    },
    {
        'linked': '节目指南',
        'items': ['内蒙古卫视', '广西卫视', '广东卫视'],
        'subitems': [
            ['0:00 蒙古包', '1:00 蒙古包', '2:00 蒙古包', '3:00 蒙古包', '4:00 蒙古包', '5:00 蒙古包', '6:00 蒙古包', '7:00 蒙古包', '8:00 蒙古包', '9:00 蒙古包'],
            ['0:00 狐妖小红娘', '1:00 墓王之王', '2:00 灵能百分百', '3:00 弹完论破', '4:00 勇者大冒险', '5:00 剑风传奇', '6:00 亚尔斯兰', '7:00 少女月刊', '8:00 我的英雄学院', '9:00 青春波纹'],
            ['0:00 JOJO', '1:00 龙珠', '2:00 show by rock', '3:00 超自然9人组', '4:00 漂泊者', '5:00 亚人', '6:00 终末的一砸他', '7:00 食戟', '8:00 干物妹小埋', '9:00 FLIP']
        ]
    }
];
var ProgramGuide = React.createClass({
    getInitialState: function () {
        return {
            linked: '',//判断此页为哪一个子菜单
            menu: '主菜单',//判断是否是主菜单
            likearray: [],//喜爱频道的选项栈
            // supindex:0
        };
    },
    tiaozhuan: function (value, index, array, event) {
        var x = event.which || event.keyCode;
        if (x == 13 && this.state.menu == '主菜单') {//主菜单按enter键
            this.setState({linked: value, menu: ''});
        } else if ((x == 27 || x == 8) && this.state.menu == '') {//子菜单按esc & backspace键
            this.setState({linked: '', menu: '主菜单', subisactive: false});
        } else if (x == 40 && index <= array.length && this.state.linked != '节目指南') {//按向下键
            if (index == array.length - 1) {//判断是否是最后一项
                this.refs['active' + index].style.backgroundColor = 'transparent';
                this.refs.active0.style.backgroundColor = 'red';
                this.refs.active0.focus();
            } else {
                this.refs['active' + (index)].style.backgroundColor = 'transparent';
                this.refs['active' + (index + 1)].style.backgroundColor = 'red';
                this.refs['active' + (index + 1)].focus();
            }
        } else if (x == 38 && index >= 1 && this.state.linked != '节目指南') {//按向上键
            this.refs['active' + (index)].style.backgroundColor = 'transparent';
            this.refs['active' + (index - 1)].style.backgroundColor = 'red';
            this.refs['active' + (index - 1)].focus();
        } else if (x == 76 && this.state.linked != '节目指南') {//按L键
            this.refs['active' + (index)].style.backgroundColor = 'orange';
            if (this.state.likearray.indexOf(value) == -1) {
                this.state.likearray.push(value);
            }
        }
    },
    componentDidMount: function () {//DOM加载之后
        this.refs.active0.style.backgroundColor = "red";
        this.refs.active0.focus();
    },
    componentDidUpdate: function (prevProps, prevState) {//DOM刷新之后
        if (this.state.linked != '喜爱频道' && this.state.linked != '节目指南') {
            this.refs.active0.focus();
            this.refs.active0.style.backgroundColor = "red";
        } else if (this.state.linked == '喜爱频道') {
            if (this.state.likearray.length == 0) {//喜爱频道没有任何选项的情况
                this.refs.biaoti.focus();
            } else {
                this.refs.active0.focus();
                this.refs.active0.style.backgroundColor = "red";
            }
        }
    },
    render: function () {
        var that = this;
        var lianjie = this.state.linked;
        var zhucaidan = this.state.menu;
        var likearray = this.state.likearray;
        if (zhucaidan == '主菜单') {
            var repoList = data[0].items.map(function (v, i, a) {
                return (
                    <li><i className={"iconfont " + data[0].cName[i]}></i>
                        <a tabIndex={i} ref={'active' + i} onKeyDown={that.tiaozhuan.bind(this, v, i, a)}>{v}</a>
                    </li>
                )
            });
            var smallList = data[0].list.map(function (v, i) {
                return (<li>{v}</li>)
            });
            return (
                <main>
                    <h1>{data[0].menu}</h1>
                    <ul>{repoList}</ul>
                    <hr/>
                    <ul>{smallList}</ul>
                    <img src={data[0].rightTopimage} alt=""/>
                </main>
            )
        } else if (lianjie == '频道浏览') {
            var repoList = data[1].items.map(function (v, i, a) {
                return (
                    <li style={{height: 25}}>
                        <a tabIndex={i} ref={'active' + i} onKeyDown={that.tiaozhuan.bind(this, v, i, a)}>{v}</a>
                    </li>
                )
            });
            var smallList = data[1].list.map(function (v, i) {
                return (<li>{v}</li>)
            });
            return (
                <main>
                    <h1>{data[1].linked}</h1>
                    <div style={{width: 200, height: 150, overflow: 'hidden', position: 'relative'}}>
                        <ul ref='myList' style={{position: 'absolute', top: 0, left: 0}}>{repoList}</ul>
                    </div>
                    <hr/>
                    <ul>{smallList}</ul>
                    <img src={data[1].rightTopimage} alt=""/>
                </main>
            )
        } else if (lianjie == '喜爱频道') {
            var repoList = likearray.map(function (v, i, a) {
                return (
                    <li style={{height: 25}}>
                        <a tabIndex={i} ref={'active' + i} onKeyDown={that.tiaozhuan.bind(this, v, i, a)}>{v}</a>
                    </li>
                )
            });
            var smallList = data[2].list.map(function (v, i) {
                return (<li>{v}</li>)
            });
            return (
                <main>
                    <h1 ref="biaoti" tabIndex="-1"
                        onKeyDown={that.tiaozhuan.bind(this, 'biaoti', 0, null)}>{data[2].linked}</h1>
                    <div style={{width: 200, height: 150, overflow: 'hidden', position: 'relative'}}>
                        <ul ref='myList' style={{position: 'absolute', top: 0, left: 0}}>{repoList}</ul>
                    </div>
                    <hr/>
                    <ul>{smallList}</ul>
                    <img src={data[2].rightTopimage} alt=""/>
                </main>
            )
        } else if (lianjie == '节目指南') {
            return (
                <JiemuZhinan func={that.tiaozhuan}/>
            )
        }

    }
});
var JiemuZhinan = React.createClass({
    getInitialState: function () {
        return {
            supindex: 0,
            subisactive: false,//判断节目指南子选项是否被选中
        };
    },
    componentDidMount: function () {
        this.refs.active0.focus();
        this.refs.active0.style.backgroundColor = "red";
    },
    isOnfocus: function (index) {
        this.setState({supindex: index});
    },
    tiaozhuan2: function (value, index, array, event) {
        var x = event.which || event.keyCode;
        if (x == 40 && index <= array.length) {//按向下键
            if (!this.state.subisactive) {//判断是否选择了节目指南的子选项
                if (index == array.length - 1) {//判断是否是最后一项
                    this.refs['active' + index].style.backgroundColor = 'transparent';
                    this.refs.active0.style.backgroundColor = 'red';
                    this.refs.active0.focus();
                } else {
                    this.refs['active' + (index)].style.backgroundColor = 'transparent';
                    this.refs['active' + (index + 1)].style.backgroundColor = 'red';
                    this.refs['active' + (index + 1)].focus();
                }
            } else {
                if (index == array.length - 1) {
                    this.refs['subactiveli' + index].style.backgroundColor = 'transparent';
                    this.refs.subactiveli0.style.backgroundColor = 'red';
                    this.refs.subactiveli0.focus();
                } else {
                    this.refs['subactiveli' + (index)].style.backgroundColor = 'transparent';
                    this.refs['subactiveli' + (index + 1)].style.backgroundColor = 'red';
                    this.refs['subactiveli' + (index + 1)].focus();
                }
            }
        } else if (x == 38 && index >= 1) {//按向上键
            if (!this.state.subisactive) {
                this.refs['active' + (index)].style.backgroundColor = 'transparent';
                this.refs['active' + (index - 1)].style.backgroundColor = 'red';
                this.refs['active' + (index - 1)].focus();
            } else {
                this.refs['subactiveli' + (index)].style.backgroundColor = 'transparent';
                this.refs['subactiveli' + (index - 1)].style.backgroundColor = 'red';
                this.refs['subactiveli' + (index - 1)].focus();
            }
        } else if (x == 39) {//按左箭头
            this.state.subisactive = true;
            this.refs['active' + (index)].style.backgroundColor = 'transparent';
            this.refs['subactiveli0'].style.backgroundColor = 'red';
            this.refs['subactiveli0'].focus();
        } else if (x == 37) {
            this.state.subisactive = false;
            this.refs['subactiveli' + (index)].style.backgroundColor = 'transparent';
            this.refs['active' + (this.state.supindex)].style.backgroundColor = 'red';
            this.refs['active' + (this.state.supindex)].focus();
        }
    },
    render: function () {
        var that = this;
        var tiaozhuan = this.props.func;
        var repoList = data[3].items.map(function (v, i, a) {
            return (
                <li>
                    <a tabIndex={i} ref={'active' + i} onFocus={that.isOnfocus.bind(this, i)}
                       onKeyDown={tiaozhuan.bind(that, v, i, a)} onKeyUp={that.tiaozhuan2.bind(this, v, i, a)}>{v}</a>
                </li>
            )
        });
        var supindex = that.state.supindex;
        var subarr = data[3].subitems[supindex].map(function (vs, is, as) {
            return (
                <li><a ref={'subactiveli' + is} tabIndex={is} onKeyDown={tiaozhuan.bind(that, vs, is, as)}
                       onKeyUp={that.tiaozhuan2.bind(this, vs, is, as)}>{vs}</a></li>
            )
        });
        return (
            <main>
                <h1>{data[3].linked}</h1>
                <ul>{repoList}</ul>
                <hr/>
                <ul>{subarr}</ul>
                <hr/>
                <img src={data[0].rightTopimage} alt=""/>
            </main>
        )
    },
});
ReactDOM.render(
    <ProgramGuide/>,
    document.getElementById('TVguide')
)
/**
 * Created by G50-A on 2016/12/7.
 */

