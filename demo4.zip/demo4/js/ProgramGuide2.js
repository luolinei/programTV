var data = [
    {
        'menu': '主菜单',
        'items': ['频道浏览', '喜爱频道', '节目指南', '信息服务', '系统设置', '广播邮件', '用户账户'],
        'cName': ['icon-wxbbiaowang', 'icon-wxbgongju', 'icon-wxbmingxingdianpu', 'icon-wxbpinpaibao', 'icon-wxbpinpaibao', 'icon-wxbzhuye', 'icon-wxbsousuotuiguang'],
        'list': ['频道名称', '节目名称', '播放时间'],
        'footerimage': '',
        'rightTopimage': 'img/a1.jpg',
        'rightBottomimage': ''
    },
    {
        'linked': '频道浏览',
        'items': ['内蒙古卫视', '广西卫视', '广东卫视','CCTV-1','CCTV-2','CCTV-3','CCTV444','CCTV555','cctba','ccbe5'],
        'list': ['内蒙古卫视', '转播中央台新闻', '19:00-19:30'],
        'footerimage': '',
        'rightTopimage': 'img/a2.jpg',
        'rightBottomimage': ''
    },
    {
        'linked': '喜爱频道',
        'items': [],
        'list': ['马猴烧酒育成计划', '夏目', '超自然9'],
        'footerimage': '',
        'rightTopimage': 'img/a3.jpg',
        'rightBottomimage': ''
    },
    {
        'linked':'节目指南',
        'items':['内蒙古卫视','广西卫视','广东卫视'],
        'subitems':[
            ['0:00 aaaa','1:00 bbbb','2:00 cccc','3:00 dddd','4:00 eeee','5:00 ffff','6:00 gggg','7:00 hhhh','8:00 iiii','9:00 jjjj'],
            ['0:00 1111','1:00 2222','2:00 3333','3:00 4444','4:00 555e','5:00 ffff','6:00 gggg','7:00 hhhh','8:00 iiii','9:00 jjjj'],
            ['0:00 JOJO','1:00 龙珠','2:00 show by rock','3:00 超自然9人组','4:00 漂泊者','5:00 亚人','6:00 gggg','7:00 hhhh','8:00 iiii','9:00 jjjj']
        ]
    }
];
var ProgramGuide = React.createClass({
    getInitialState: function () {
        return {
            linked: '',//判断此页为哪一个子菜单
            menu: '主菜单',//判断是否是主菜单
            likearray:[],//喜爱频道的选项栈
            subisactive:false,//判断节目指南子选项是否被选中
            supindex:0
        };
    },
    tiaozhuan:function (value,index,array,event) {
        var x=event.which||event.keyCode;
        if(x==13&&this.state.menu=='主菜单'){//主菜单按enter键
            this.setState({linked: value, menu: ''});
        }else if((x==27||x==8)&&this.state.menu==''){//子菜单按esc & backspace键
            this.setState({linked:'',menu:'主菜单',subisactive:false});
        }else if(x==40&&index<=array.length){//按向下键
            if(!this.state.subisactive){//判断是否选择了节目指南的子选项
                if(index==array.length-1){//判断是否是最后一项
                    this.refs['active'+index].style.backgroundColor='transparent';
                    this.refs.active0.style.backgroundColor='red';
                    this.refs.active0.focus();
                    if(this.state.linked=='节目指南'){

                    }
                }else{
                    this.refs['active'+(index)].style.backgroundColor='transparent';
                    this.refs['active'+(index+1)].style.backgroundColor='red';
                    this.refs['active'+(index+1)].focus();
                    if(this.state.linked=='节目指南'){

                    }
                }
            }else{
                if(index==array.length-1){
                    this.refs['subactiveli'+index].style.backgroundColor='transparent';
                    this.refs.subactiveli0.style.backgroundColor='red';
                    this.refs.subactiveli0.focus();
                }else{
                    this.refs['subactiveli'+(index)].style.backgroundColor='transparent';
                    this.refs['subactiveli'+(index+1)].style.backgroundColor='red';
                    this.refs['subactiveli'+(index+1)].focus();
                }
            }
        }else if(x==38&&index>=1) {//按向上键
            if(!this.state.subisactive){
                this.refs['active' + (index)].style.backgroundColor = 'transparent';
                this.refs['active' + (index - 1)].style.backgroundColor = 'red';
                this.refs['active' + (index - 1)].focus();
                if(this.state.linked=='节目指南'){

                }
            }else{
                this.refs['subactiveli' + (index)].style.backgroundColor = 'transparent';
                this.refs['subactiveli' + (index - 1)].style.backgroundColor = 'red';
                this.refs['subactiveli' + (index - 1)].focus();
            }
        }else if(x==76){//按L键
            this.refs['active'+(index)].style.backgroundColor='orange';
            if(this.state.likearray.indexOf(value)==-1){
                this.state.likearray.push(value);
            }
        }else if(x==39){//按左箭头
            this.state.subisactive=true;
            this.refs['active'+(index)].style.backgroundColor='transparent';
            this.refs['subactiveli0'].style.backgroundColor='red';
            this.refs['subactiveli0'].focus();
        }
    },
    isonfocus:function (index) {//判断节目指南哪个子选项显示
        this.state.supindex=index;
        console.log(this.state.supindex)
        // this.setState({supindex:index});
    },
    componentDidMount: function () {//DOM加载之后
        this.refs.active0.style.backgroundColor = "red";
        this.refs.active0.focus();
    },
    componentDidUpdate:function(prevProps, prevState) {//DOM刷新之后
        if(this.state.linked!='喜爱频道'){
            this.refs.active0.focus();
            this.refs.active0.style.backgroundColor = "red";
            // if(this.state.linked=='节目指南'){
            //     this.refs.active0.className='xuanzhong';
            //     this.refs.subactivedd0.style.display='block';
            // }
        }else{
            if (this.state.likearray.length == 0) {//喜爱频道没有任何选项的情况
                this.refs.biaoti.focus();
            }else{
                this.refs.active0.focus();
                this.refs.active0.style.backgroundColor = "red";
            }
        }
    },
    render: function () {
        var that = this;
        var lianjie = this.state.linked;
        var zhucaidan = this.state.menu;
        var likearray=this.state.likearray;
        if (zhucaidan == '主菜单') {
            var repoList = data[0].items.map(function (v, i,a) {
                return (
                    <li><i className={"iconfont " + data[0].cName[i]}></i>
                        <a tabIndex={i} ref={'active'+i} onKeyDown={that.tiaozhuan.bind(this, v, i,a)}>{v}</a>
                    </li>
                )
            });
            var smallList = data[0].list.map(function (v, i) {
                return (<li>{v}</li>)
            });
            return (
                <main>
                    <h1>{data[0].menu}</h1>
                    <ul>{repoList}</ul>
                    <hr/>
                    <ul>{smallList}</ul>
                    <img src={data[0].rightTopimage} alt=""/>
                </main>
            )
        } else if (lianjie == '频道浏览') {
            var repoList = data[1].items.map(function (v, i,a) {
                return (
                    <li style={{height:25}}>
                        <a tabIndex={i} ref={'active'+i} onKeyDown={that.tiaozhuan.bind(this,v,i,a)}>{v}</a>
                    </li>
                )
            });
            var smallList = data[1].list.map(function (v, i) {
                return (<li>{v}</li>)
            });
            return (
                <main>
                    <h1>{data[1].linked}</h1>
                    <div style={{width:200,height:150,overflow:'hidden',position:'relative'}}><ul ref='myList' style={{position:'absolute',top:0,left:0}}>{repoList}</ul></div>
                    <hr/>
                    <ul>{smallList}</ul>
                    <img src={data[1].rightTopimage} alt=""/>
                </main>
            )
        } else if (lianjie == '喜爱频道') {
            var repoList = likearray.map(function (v, i,a) {
                return (
                    <li style={{height:25}}>
                        <a tabIndex={i} ref={'active'+i} onKeyDown={that.tiaozhuan.bind(this,v,i,a)}>{v}</a>
                    </li>
                )
            });
            var smallList = data[2].list.map(function (v, i) {
                return (<li>{v}</li>)
            });
            return (
                <main>
                    <h1 ref="biaoti" tabIndex="-1" onKeyDown={that.tiaozhuan.bind(this,'biaoti',0,null)}>{data[2].linked}</h1>
                    <div style={{width:200,height:150,overflow:'hidden',position:'relative'}}><ul ref='myList' style={{position:'absolute',top:0,left:0}}>{repoList}</ul></div>
                    <hr/>
                    <ul>{smallList}</ul>
                    <img src={data[2].rightTopimage} alt=""/>
                </main>
            )
        }else if(lianjie=='节目指南'){
            var repoList = data[3].items.map(function (v,i,a) {
                return (
                    <li>
                        <a tabIndex={i} ref={'active'+i} onKeyDown={that.tiaozhuan.bind(that,v,i,a)} onFocus={that.isonfocus.bind(that,i)}>{v}</a>
                    </li>
                )
            });
            var supindex=that.state.supindex;
            var subarr=data[3].subitems[supindex].map(function (vs, is, as) {
                return(
                    <li><a ref={'subactiveli'+is} tabIndex={is} onKeyDown={that.tiaozhuan.bind(that,vs,is,as)}>{vs}</a></li>
                )
            });
            return (
                <main>
                    <h1>{data[3].linked}</h1>
                    <ul>{repoList}</ul>
                    <ul>{subarr}</ul>
                    <hr/>
                    <img src={data[0].rightTopimage} alt=""/>
                </main>
            )
        }

    }
});
ReactDOM.render(
    <ProgramGuide/>,
    document.getElementById('TVguide')
)
/**
 * Created by G50-A on 2016/12/7.
 */

