import 'core-js/fn/object/assign';
import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/Main';

let eventHandle = require("./components/util");

// Render the main component into the dom

function render() {
  var route = window.location.hash.substr(1);
  ReactDOM.render(<App route={route} />, document.getElementById('app'));
}
window.addEventListener("hashchange",render,false);
render();

eventHandle();
