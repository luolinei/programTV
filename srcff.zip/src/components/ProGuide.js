/**
 * Created by dudu on 2017/1/5.
 */
require('normalize.css/normalize.css');
require('styles/App.css');

import React from 'react';

import FootImg from './subComponents/FootImg'
let FootPicShow = FootImg.footPicShow("foot");

import GuideList from './subComponents/GuideList'


class Guide extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      guideList:this.props.data.programList,    // 取得了数据库中programList的内容
      supindex:this.props.data.supindex    //是一个数组
    };
    // console.log(this.state.chanList);
  }

  componentDidMount(){
    // console.log("节目指南的supindex"+this.state.supindex)
  }

  componentDidUpdate(){
    // console.log("+++节目指南的supindex+++"+this.state.supindex)
  }

  render() {
    return(
      <div>
        <h1>节目指南</h1>
        <GuideList supindex={this.state.supindex} guideList={this.state.guideList} />
        <FootPicShow />
      </div>
    );
  }
}



export default Guide;
