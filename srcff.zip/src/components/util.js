/**
 * Created by dudu on 2017/1/7.
 */
module.exports = function eventHandler() {
  window.onload = function () {
    document.onkeyup = function (e) {
      // alert(1)
      let keyCode = e.which || e.keyCode;
      /*e.stopPropagation();
      e.preventDefault();*/
      // alert(keyCode)
      if (keyCode == 8 && window.location.hash){
        window.history.back();
        /*window.myBack = true; //设置了一个全局bool值（不知道小伙子想解决什么问题，我要吸取的是他的全局变量的写法）
        console.log(myBack)*/
        // window.location.reload();
      }

      /*if (!window.location.hash){
        document.onkeyup = null;
      }*/
    }
  };

 /* function hasClass(ele,cls) {
    return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
  }

  function addClass(ele,cls) {
    if (!this.hasClass(ele,cls)) ele.className += " "+cls;
  }

  function removeClass(ele,cls) {
    if (hasClass(ele,cls)) {
      var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
      ele.className=ele.className.replace(reg,' ');
    }
  }

  function $(ele) {
    if(document.querySelectorAll(ele).length==1){
      return document.querySelector(ele);
    }
    else {
      document.querySelectorAll(ele);
    }
  }*/
};
