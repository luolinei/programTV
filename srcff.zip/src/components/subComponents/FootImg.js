require('normalize.css/normalize.css');
require('styles/App.css');
require('styles/style.css');

import React from 'react';

let style ={
  width:"800px",
  height:"50px"
};

function PicShow(imgid) {
  let footImg = require("../../images/"+imgid+".jpg");

  class FImg extends React.Component {
    render() {
      return (
        <div className="footImg">
          <img style={style} src={footImg} />
        </div>
      );
    }
  }
  FImg.defaultProps = {
  };

  return FImg;
}

var obj = {footPicShow:PicShow};
export default obj;






