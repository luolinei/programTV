/**
 * Created by dudu on 2017/1/4.
 */
require('normalize.css/normalize.css');
require('styles/App.css');
require('styles/style.css');

import React from 'react';

/*let time_range1 = require("../timeArea1");
time_range1 ("21:30", "23:30", "23:22");

import timeArea from '../timeArea'
let timearea = timeArea.timeArea("21:30", "23:30", "12:22");  // timearea 不是一个函数，而是一个返回值
timearea;

let time_range2 = require("../timeArea2");
time_range2();     // 不能写成 time_range; 要作为一个函数进行调用*/

let timeRange = require("./playTime");
// timeRange ("21:30", "23:30");

function getImg(imgid) {
  let menuIcon = require("../../images/menu_"+imgid+".png");
  return menuIcon;
}

let listBox = [
  {
    'items':'频道浏览',
    'image':getImg("1"),
    'route':'#channel'
  },
  {
    'items':'喜爱频道',
    'image':getImg("2"),
    'route':'#favorite'
  },
  {
    'items':'节目指南',
    'image':getImg("3"),
    'route':'#guide'
  },
  {
    'items':'信息服务',
    'image':getImg("4"),
    'route':'#infoServe'
  },
  {
    'items':'广播邮件',
    'image':getImg("5"),
    'route':'#mail'
  },
  {
    'items':'用户账户',
    'image':getImg("6"),
    'route':'#account'
  },
  {
    'items':'系统设置',
    'image':getImg("7"),
    'route':'#set'
  }
];




class AppComponent extends React.Component {

  constructor(props){
    super(props);
    this.state = {
      supindex:this.props.supindex,    // 是一个数组
      subisactive:false,
      chanList:this.props.chanList,
    /*  chName:this.props.chName,                // 是一个数组
      currentPro:this.props.currentPro,
      currentTime:this.props.currentTime*/
    };
    // console.log("+++++++"+this.state.supindex[0]+"+++++++++")

  }


  handleKeyDown(value,index,array,event){
    let keyCode = event.which || event.keyCode;
    // console.log(keyCode);
    if (keyCode==40){ //按向下键
      if(index!=array.length-1){
        this.refs['menu'+index].style.backgroundColor = 'transparent';
        this.refs['menu'+(index+1)].style.backgroundColor = 'orange';
        this.refs['menu'+(index+1)].focus();
      }
      else {
        this.refs['menu'+index].style.backgroundColor = 'transparent';
        this.refs.menu0.style.backgroundColor = 'orange';
        this.refs.menu0.focus();
      }
    }

    if (keyCode==38){ //按向上键
      if(index!=0){
        this.refs['menu'+index].style.backgroundColor = 'transparent';
        this.refs['menu'+(index-1)].style.backgroundColor = 'orange';
        this.refs['menu'+(index-1)].focus();
      }
    }
  }

  playTime(){
    var playarr =this.state.chanList[this.state.supindex[0]].playTime;
    // console.log(playarr);
    for(let i=0;i<playarr.length;i++){
      let playarea = playarr[i];
      let playsplit = playarea.split("-");
      let playsplit0 = playsplit[0];
      let playsplit1 = playsplit[1];

      // console.log(timeRange(playsplit0,playsplit1));
      if (timeRange(playsplit0,playsplit1)){
        return i;
      }
    }
  }

  componentDidMount(){
    let chanListi = this.state.chanList[this.state.supindex[0]]; //得到的是哪一个频道内容（包括频道名称，该频道所有的播放时段及播放节目）

    this.refs.menu0.style.backgroundColor = "orange";
    this.refs.menu0.focus();
    // console.log(this.playTime());
    let j = this.playTime();
    let src = chanListi.proVideo[j];
    // console.log(src);
    this.refs.video.src = "../../images/"+src+".jpg";


  }

  render() {

    let that = this;

    /*****************把data.json里的频道都push到一个数组里，方便操作*********************/
    let chanListi = that.state.chanList[that.state.supindex[0]]; //得到的是哪一个频道内容（包括频道名称，该频道所有的播放时段及播放节目）

    let channel = [];
    for(let i=0;i<that.state.chanList.length;i++){
      channel.push(that.state.chanList[i].channel);
    }
    // console.log("把频道放到一个数组里:"+channel);
    let channeli = channel.indexOf(chanListi.channel);
    console.log("这个频道在我自己的频道数组channel里的索引是："+channeli);

    /**************************************/

    let style = {overflow:"hidden",marginBottom:"20px"};

    let listbox = listBox.map(function (v, i, a) {
      //map() 方法返回一个新数组，数组中的元素为原始数组元素调用函数处理后的值。即 listbox 是一个数组
      return (
        <li key={i}>
          <img src={v.image} />
          <a href={v.route} ref={"menu"+i} onKeyDown={that.handleKeyDown.bind(that,v,i,a)}>{v.items}</a>
        </li>
      );
    });

    return (
      <div className="menuList">
        <div style={style}>
          <div className="list">
            <ul>{listbox}</ul>  {/*listbox是数组，jsx有自动展开数组的特性*/}
          </div>
          <div className="video">
            <img ref={"video"} src="" />
          </div>
        </div>
        <div>
          <ul>
            <li>频道名称：{channel[channeli]}</li>
            <li>节目名称：{that.state.chanList[channeli].proTitle[that.playTime()]}</li>
            <li>播放时间：{that.state.chanList[channeli].playTime[that.playTime()]}</li>
          </ul>
        </div>
      </div>
    );
  }
}

AppComponent.defaultProps = {
};

export default AppComponent;
