require('normalize.css/normalize.css');
require('styles/App.css');
require('styles/style.css');

import React from 'react';

class AppComponent extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      guideList:this.props.guideList,
      supindex:this.props.supindex,   //是一个数组
      subisactive:false
    };
    // console.log(this.state.guideList)
    // console.log(this.state.supindex[0]+"=======+++++++++")
  }

  isOnfocus(index){
    this.state.supindex.splice(0,1,index);
    this.setState({
      supindex:this.state.supindex
    });
  }

  handleKeyDown(value,index,array,event){
    var x = event.which||event.keyCode;
    if (x==40){
      if(!this.state.subisactive){
        if (index!=array.length-1){
          this.refs['active' + (index)].style.backgroundColor = 'transparent';
          this.refs['active' + (index + 1)].style.backgroundColor = 'orange';
          this.refs['active' + (index + 1)].focus();
        }
      }
    }
  }

  componentDidMount(){
    let j = this.state.supindex[0];
    this.refs["active"+j].focus();
    this.refs["active"+j].style.backgroundColor = "orange";
  }

  render() {
    let that = this;

    /*****************把data.json里的频道都push到一个数组里，方便操作*********************/
      // let chanListi = that.state.info[that.state.supindex[0]; //得到的是哪一个频道内容（包括频道名称，该频道所有的播放时段及播放节目）

    let channel = [];
    for(let i=0;i<that.state.guideList.length;i++){
      channel.push(that.state.guideList[i].channel);
    }
    // console.log("把频道放到一个数组里:"+channel);
    // let channeli = channel.indexOf(chanListi.channel);
    // console.log("这个频道在我自己的频道数组channel里的索引是："+channeli);

    /**************************************/

    let chanBox = channel.map(function (v, i, a) {
      return (
        <li key={i}>
          <a href="" ref={"active"+i} onKeyDown={that.handleKeyDown.bind(that,v,i,a)} onFocus={that.isOnfocus.bind(that,i)}>{v}</a>
        </li>
      );
    });

    return (
      <div className="chanList">
        <p>电视频道列表</p>
        <div className="out1">
          <div className="out2"><ul className="list">{chanBox}</ul></div>
        </div>
        <div className="video">
          <img src="../../images/a1.jpg" />
        </div>
      </div>
    );
  }
}

AppComponent.defaultProps = {
};

export default AppComponent;
