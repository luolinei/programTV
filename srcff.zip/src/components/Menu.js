/**
 * Created by dudu on 2017/1/4.
 */
require('normalize.css/normalize.css');
require('styles/App.css');

import React from 'react';

import MenuList from './subComponents/MenuList'

import FootImg from './subComponents/FootImg'
let FootPicShow = FootImg.footPicShow("foot");  // FootImg是引进来时的名称 ，footPicShow是被引进来的那个RightImg里最后导出的那个对象的属性名


class Menu extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      chanList:this.props.data.programList,
      chName:this.props.data.chName,
      currentPro:this.props.data.currentPro,
      currentTime:this.props.data.currentTime,
      supindex:this.props.data.supindex
    };
    // console.log("=============="+this.state.supindex+"============")
  }
  render() {
    return (
      <div>
        <h1>主菜单</h1>
        <MenuList supindex={this.state.supindex} chanList={this.state.chanList} chName={this.state.chName} currentPro={this.state.currentPro} currentTime={this.state.currentTime} />
        <FootPicShow />
      </div>
    );
  }
}

Menu.defaultProps = {
};

export default Menu;
