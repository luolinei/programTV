require('normalize.css/normalize.css');
require('styles/App.css');

import React from 'react';

import Menu from './Menu'
import Channel from './Channel'
import Guide from './ProGuide'

import data from './data.json'



class Main extends React.Component {
  constructor(props){
    super(props);
    this.state = data;      // 整个json数据（其实就是数据库）
    console.log(this.state);
  }

  render() {
    let Child;
    switch (this.props.route){
      case 'channel' : Child = Channel; break;
      case 'guide' : Child = Guide ; break;
      default : Child = Menu;
    }

    return (
      <div>
        <Child data={this.state} />
      </div>
    );
  }
}



export default Main;
