/**
 * Created by dudu on 2017/1/5.
 */
require('normalize.css/normalize.css');
require('styles/App.css');

import React from 'react';

import FootImg from './subComponents/FootImg'
let FootPicShow = FootImg.footPicShow("foot");

import ChannelList from './subComponents/ChannelList'


class Channel extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      chanList:this.props.data.programList,    // 取得了数据库中programList的内容
      supindex:this.props.data.supindex    //是一个数组
    };
    // console.log(this.state.chanList);
  }

  componentDidMount(){
    console.log("Channel频道浏览的supindex"+this.state.supindex)
  }

  componentDidUpdate(){
    console.log("+++Channel频道浏览的supindex+++"+this.state.supindex)
  }

  render() {
    return(
      <div>
        <h1>频道浏览</h1>
        <ChannelList supindex={this.state.supindex} chanInfo={this.state.chanList} />
        <FootPicShow />
      </div>
    );
  }
}



export default Channel;
